﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyTools;
namespace ExternalGetway
{
    public class ExternalGateWay : IExternalGateWay
    {
        FileDetails objfile = new FileDetails();
        public int DisplaySize(string strSize,string strFileName)
        {
            return objfile.Size(strFileName);
        }



        public string DisplayVersion(string strVersion,string strFileName)
        {
            return objfile.Version(strFileName);
        }
    }
}
