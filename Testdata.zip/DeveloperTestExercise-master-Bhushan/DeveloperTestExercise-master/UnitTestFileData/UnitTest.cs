﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestFileData
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void TestMethodVersion()
        {
            FileData.Program.DisplayVersion("-v", "c:/CE.txt");

        }

        [TestMethod]
        public void TestMethodSize()
        {
            FileData.Program.DisplayVersion("-s", "c:/CE.txt");
        }
    }
}
