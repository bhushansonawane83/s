﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BL;
namespace FileData
{
    public class UI : IBL
    {
        private IBL _ibl;

        public UI(IBL ibl)
        {
            _ibl = ibl;
        }

        public int DisplaySize(string strSize, string strFileName)
        {
            return _ibl.DisplaySize( strSize, strFileName);
         
        }

        public string DisplayVersion(string strVersion, string strFileName)
        {
            return _ibl.DisplayVersion(strVersion,strFileName);
        }
    }
}
