﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExternalGetway;
namespace BL
{
    public class Business:IExternalGateWay
    {
        private IExternalGateWay _iel;

        public Business(IExternalGateWay iel)
        {
            _iel = iel;
        }
        public int DisplaySize(string strSize, string strFileName)
        {
            return _iel.DisplaySize(strSize,strFileName);
            //throw new NotImplementedException();
        }

        public string DisplayVersion(string strVersion,string strFileName)
        {
            return _iel.DisplayVersion(strVersion,strFileName);
        }
    }
}
